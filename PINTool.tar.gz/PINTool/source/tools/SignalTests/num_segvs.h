/*
 * Copyright (C) 2009-2009 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

#define NUM_SEGVS 10
