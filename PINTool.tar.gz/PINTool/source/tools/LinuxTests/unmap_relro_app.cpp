/*
 * Copyright (C) 2017-2021 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

#include <iostream>
using std::cout;
using std::endl;

int main()
{
    cout << "Test passed successfully" << endl;

    return 0;
}
