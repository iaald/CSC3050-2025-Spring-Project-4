/*
 * Copyright (C) 2023-2023 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

#include <stdio.h>

int main()
{
    printf("Hello world\n");
    return 0;
}
