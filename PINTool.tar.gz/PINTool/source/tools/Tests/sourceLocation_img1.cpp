/*
 * Copyright (C) 2011-2011 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

void* dummy1 = 0;
