/*
 * Copyright (C) 2011-2021 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

#include <stdio.h>
#include <string.h>

int main(int argc, char** argv)
{
    fprintf(stdout, "I am the child_sig_while_execv_simple_app \n");
    return 0;
}
