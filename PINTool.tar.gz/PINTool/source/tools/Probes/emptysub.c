/*
 * Copyright (C) 2007-2021 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

// This little application is used to test replacing a function with an empty routine.
//
#include <stdio.h>

void Bar(int a) { printf("Bar: %d\n", a); }
