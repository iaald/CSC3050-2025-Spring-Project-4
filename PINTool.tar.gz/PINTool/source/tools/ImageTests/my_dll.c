/*
 * Copyright (C) 2009-2021 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

#include <math.h>

double my_dll_sin(double x) { return sin(x); }

int my_dll_inc1(int y) { return y + 1; }
